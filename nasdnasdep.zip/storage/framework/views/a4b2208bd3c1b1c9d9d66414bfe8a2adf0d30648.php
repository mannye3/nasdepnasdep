<?php $__env->startSection('content'); ?>
 <!-- main header @e  -->
                <!-- content @s  -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="nk-block-head nk-block-head-sm">
                                    <div class="nk-block-between">
                                        <div class="nk-block-head-content">
                                            <h3 class="nk-block-title page-title">Roles</h3>
                                            <div class="nk-block-des text-soft">

                                            </div>
                                        </div><!-- .nk-block-head-content -->
                                        <div class="nk-block-head-content">
                                            <div class="toggle-wrap nk-block-tools-toggle">
                                                <a href="#" class="btn btn-icon btn-trigger toggle-expand mr-n1" data-target="pageMenu"><em class="icon ni ni-menu-alt-r"></em></a>
                                                <div class="toggle-expand-content" data-content="pageMenu">
                                                    <ul class="nk-block-tools g-3">
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-create')): ?> <li><a href="<?php echo e(route('roles.create')); ?>" class="btn btn-white btn-outline-light"><em class="icon ni ni-download-cloud"></em><span>Create New Role</span></a></li> <?php endif; ?>

                                                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalForm">Modal With Form</button>

                                                    </ul>
                                                </div>
                                            </div><!-- .toggle-wrap -->
                                        </div><!-- .nk-block-head-content -->
                                    </div><!-- .nk-block-between -->
                                </div><!-- .nk-block-head -->
                                <div class="nk-block">
                                   <div class="card card-preview">
                                            <div class="card-inner">
                                                <?php if($message = Session::get('success')): ?>
                                                    <div class="alert alert-success">
                                                        <p><?php echo e($message); ?></p>
                                                    </div>
                                                <?php endif; ?>

                                                <table class="datatable-init nk-tb-list nk-tb-ulist table-bordered" data-auto-responsive="false">
                                                    <thead>
                                                        <tr class="nk-tb-item nk-tb-head">
                                                            <th class="nk-tb-col nk-tb-col-check">
                                                                <div class="custom-control custom-control-sm custom-checkbox notext">

                                                                    <label class="custom-control-label" for="uid"></label>
                                                                </div>
                                                            </th>
                                                            <th class="nk-tb-col"><span class="sub-text">Name</span></th>
                                                            <th class="nk-tb-col tb-col-mb"><span class="sub-text">Action</span></th>


                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr class="nk-tb-item">
                                                            <td class="nk-tb-col nk-tb-col-check">
                                                                <?php echo e(++$i); ?>

                                                            </td>
                                                            <td class="nk-tb-col">
                                                                <div class="user-card">

                                                                    <div class="user-info">
                                                                        <?php echo e($role->name); ?>

                                                                    </div>
                                                                </div>
                                                            </td>

                                                            <td class="nk-tb-col tb-col-mb" data-order="580.00">
                                                                <a class="btn btn-info" href="" data-toggle="modal" data-target="#showModal-<?php echo e($role->id); ?>">Show</a>

                                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-edit')): ?>
                                                                    <a class="btn btn-primary" href="" data-toggle="modal" data-target="#editModal-<?php echo e($role->id); ?>">Edit</a>

                                                                <?php endif; ?>
                                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-delete')): ?>
                                                                    <?php echo Form::open(['method' => 'DELETE','route' => ['roles.destroy', $role->id],'style'=>'display:inline']); ?>

                                                                    <a class="btn btn-danger" href="" data-toggle="modal" data-target="#deleteModal-<?php echo e($role->id); ?>">Delete</a>
                                                                        
                                                                    <?php echo Form::close(); ?>

                                                                <?php endif; ?>
                                                            </td>


                                                        </tr><!-- .nk-tb-item  -->
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </tbody>
                                                </table>
                                            </div>
                                        </div><!-- .card-preview -->
                                </div><!-- .nk-block -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content @e  -->




                 <!-- ADD Modal Form -->
    <div class="modal fade" tabindex="-1" id="modalForm">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Customer Info</h5>
                    <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                        <em class="icon ni ni-cross"></em>
                    </a>
                </div>
                <div class="modal-body">
                    <form method="POST" action="<?php echo e(route('roles.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label class="form-label" for="full-name">Name</label>
                            <div class="form-control-wrap">
                                <input name="name" type="text" class="form-control" id="full-name" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Permission: </label>
                            <ul class="custom-control-group g-3 align-center">
                                <li>


                                        <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label><?php echo e(Form::checkbox('permission[]', $value->id, false, array('class' => 'name'))); ?>

                                        <?php echo e($value->name); ?></label>
                                    <br/>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </li>

                            </ul>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-lg btn-primary">Save </button>
                        </div>
                    </form>
                </div>
                <div class="modal-footer bg-light">
                    <span class="sub-text"></span>
                </div>
            </div>
        </div>
    </div>


    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <!-- SHOW Modal Form -->
    <div class="modal fade" tabindex="-1" id="showModal-<?php echo e($role->id); ?>">
       <div class="modal-dialog" role="document">
           <div class="modal-content">
               <div class="modal-header">
                   <h5 class="modal-title"><?php echo e($role->name); ?></h5>
                   <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                       <em class="icon ni ni-cross"></em>
                   </a>
               </div>
               <div class="modal-body">

                       <div class="form-group">
                           <label class="form-label" for="full-name">Name</label>
                           <div class="form-control-wrap">
                               <input name="name" readonly value="<?php echo e($role->name); ?>" type="text" class="form-control" id="full-name" required>
                           </div>
                       </div>

                       <div class="form-group">
                           <label class="form-label">Permission: </label>
                           <ul class="custom-control-group g-3 align-center">
                               <li>

                                    <?php
                                        $rolePermissions = DB::table("role_has_permissions")->where("role_has_permissions.role_id",$role->id)
                                       ->pluck('role_has_permissions.permission_id','role_has_permissions.permission_id')
                                       ->all();

                                       ?>




                                   <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <label><?php echo e(Form::checkbox('permission[]', $value->id, in_array($value->id, $rolePermissions) ? true : false, array('disabled'))); ?>

                                   <?php echo e($value->name); ?></label>
                               <br/>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                               </li>

                           </ul>
                       </div>

               </div>
               <div class="modal-footer bg-light">
                   <span class="sub-text"></span>
               </div>
           </div>
       </div>
   </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                     <!-- EDIT Modal Form -->
                     <div class="modal fade" tabindex="-1" id="editModal-<?php echo e($role->id); ?>">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Edit <?php echo e($role->name); ?></h5>
                                    <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                                        <em class="icon ni ni-cross"></em>
                                    </a>
                                </div>
                                <div class="modal-body">
                                    <?php echo Form::model($role, ['method' => 'PATCH','route' => ['roles.update', $role->id]]); ?>

                                        <div class="form-group">
                                            <label class="form-label" for="full-name">Name</label>
                                            <div class="form-control-wrap">
                                                <input name="name" value="<?php echo e($role->name); ?>" type="text" class="form-control" id="full-name" required>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="form-label">Permission: </label>
                                            <ul class="custom-control-group g-3 align-center">
                                                <li>

                                                     <?php
                                                         $rolePermissions = DB::table("role_has_permissions")->where("role_has_permissions.role_id",$role->id)
                                                        ->pluck('role_has_permissions.permission_id','role_has_permissions.permission_id')
                                                        ->all();

                                                        ?>


                                                    <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <label><?php echo e(Form::checkbox('permission[]', $value->id, in_array($value->id, $rolePermissions) ? true : false, array('class' => 'name'))); ?>

                                                    <?php echo e($value->name); ?></label>
                                                <br/>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </li>

                                            </ul>
                                        </div>

                                        <div class="form-group">
                                            <button type="submit" class="btn btn-lg btn-primary">Save </button>
                                        </div>
                                        <?php echo Form::close(); ?>

                                </div>
                                <div class="modal-footer bg-light">
                                    <span class="sub-text"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <!-- DELETE Modal Form -->
                    <div class="modal fade" tabindex="-1" id="deleteModal-<?php echo e($role->id); ?>">
                       <div class="modal-dialog" role="document">
                           <div class="modal-content">
                               <div class="modal-header">

                                   <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                                       <em class="icon ni ni-cross"></em>
                                   </a>
                               </div>
                               <div class="modal-body modal-body-lg text-center">
                                <div class="nk-modal">
                                    <em class="nk-modal-icon icon icon-circle icon-circle-xxl ni ni-cross-circle bg-danger"></em>
                                    <h4 class="nk-modal-title">You are about to delete <?php echo e($role->name); ?> Role?</h4>
                                    <div class="nk-modal-text">
                                        <div class="caption-text">You can't undo this action.</div>

                                    </div>
                                    <div class="nk-modal-action">


                                        <?php echo Form::open(['method' => 'DELETE','route' => ['roles.destroy', $role->id],'style'=>'display:inline']); ?>

                                            <button type="submit" class="btn btn-lg btn-mw btn-primary">Delete</button>
                                            <?php echo Form::close(); ?>

                                    </div>

                                </div>
                            </div><!-- .modal-body -->

                           </div>
                       </div>
                   </div>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\laravel_react\nasdnasdep\resources\views/roles/index.blade.php ENDPATH**/ ?>