<?php $__env->startSection('title'); ?> Admin Dashboard <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
                <!-- content @s  -->
                <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="nk-block-head nk-block-head-sm">
                                    <div class="nk-block-between">
                                        <div class="nk-block-head-content">
                                            <h3 class="nk-block-title page-title">Analysts</h3>
                                            <div class="nk-block-des text-soft">
                                                <p></p>
                                            </div>
                                        </div><!-- .nk-block-head-content -->
                                        <div class="nk-block-head-content">
                                            <div class="toggle-wrap nk-block-tools-toggle">
                                                <a href="#" class="btn btn-icon btn-trigger toggle-expand mr-n1" data-target="pageMenu"><em class="icon ni ni-menu-alt-r"></em></a>
                                                <div class="toggle-expand-content" data-content="pageMenu">
                                                    <ul class="nk-block-tools g-3">
                                                        <li><a href="<?php echo e(url('add_company')); ?>" class="btn btn-white btn-outline-light"><em class="icon ni ni-plus"></em><span>Add New Company</span></a></li>

                                                    </ul>
                                                </div>
                                            </div><!-- .toggle-wrap -->
                                        </div><!-- .nk-block-head-content -->
                                    </div><!-- .nk-block-between -->
                                </div><!-- .nk-block-head -->
                                <div class="nk-block">
                                   <div class="card card-preview">
                                            <div class="card-inner">

                                                <div class="text-left">
                                                    <?php if(Session::has('success')): ?>
                                                   <div class="example-alert">
                                                       <div class="alert alert-success alert-icon alert-dismissible">
                                                           <em class="icon ni ni-cross-circle"></em>
                                                           <strong><?php echo e(Session::get('success')); ?></strong>
                                                       <button class="close" data-dismiss="alert"></button>
                                                   </div>
                                               </div>
                                                   </div>

                                                   <?php endif; ?>



                                                   <?php if($errors->any()): ?>
                                                   <div class="alert alert-danger">
                                                       <ul>
                                                           <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                       <li><?php echo e($error); ?></li>
                                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                       </ul>

                                                   </div>

                                                   <?php endif; ?>
                                               </div>

                                               <table class="datatable-init-export nk-tb-list nk-tb-ulist table-bordered" data-auto-responsive="false">
                                                    <thead>
                                                        <tr class="nk-tb-item nk-tb-head">

                                                            <th class="nk-tb-col"><span class="sub-text">#</span></th>
                                                            <th class="nk-tb-col"><span class="sub-text">Name</span></th>
                                                            <th class="nk-tb-col tb-col-mb"><span class="sub-text">Contact</span></th>
                                                            <th class="nk-tb-col tb-col-md"><span class="sub-text">Enterpises</span></th>
                                                            <th class="nk-tb-col tb-col-md"><span class="sub-text">Pools</span></th>


                                                            <th class="nk-tb-col nk-tb-col-tools">
                                                                Action
                                                            </th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $analysts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $analyst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr class="nk-tb-item">
                                                            <td class="nk-tb-col nk-tb-col-check">
                                                                 <?php echo e($loop->iteration); ?>

                                                            </td>
                                                            <td class="nk-tb-col">
                                                                <div class="user-card">
                                                                <span><?php echo e($analyst->company->name); ?></span>
                                                            </td>
                                                            <td class="nk-tb-col">
                                                                <div class="user-card">
                                                                    <span><?php echo e($analyst->company->type); ?></span>
                                                            </td>
                                                            <td class="nk-tb-col tb-col-md">
                                                                <span><?php echo e($analyst->company->addr); ?></span>
                                                            </td>
                                                            <td class="nk-tb-col tb-col-md">
                                                                <?php if($analyst->suspended == 0): ?>
                                                                <span class="tb-status text-success">Active</span>

                                                                <?php endif; ?>

                                                                <?php if($analyst->suspended == 1): ?>
                                                                <span class="tb-status text-danger">Disabled</span>

                                                                <?php endif; ?>
                                                            </td>





                                                            <td class="nk-tb-col nk-tb-col-tools">
                                                                <ul class="nk-tb-actions gx-1">


                                                                <li>
                                                                    <li>
                                                                        <div class="drodown">
                                                                            <a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                                                            <div class="dropdown-menu dropdown-menu-right">
                                                                                <ul class="link-list-opt no-bdr">
                                                                                    <li><a href="<?php echo e(url('analyst', $analyst->company_id)); ?>"><em class="icon ni ni-list-ol"></em><span>View</span></a></li>
                                                                                    <li><a href="" data-toggle="modal" data-target="#deleteModal-<?php echo e($analyst->company_id); ?>"><em class="icon ni ni-trash"></em><span>Delete</span></a></li>


                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </td>
                                                        </tr><!-- .nk-tb-item  -->
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </tbody>
                                                </table>

                                            </div>
                                        </div><!-- .card-preview -->
                                </div><!-- .nk-block -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content @e  -->

                <?php $__currentLoopData = $analysts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $analyst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <!-- DELETE Modal Form -->
                <div class="modal fade" tabindex="-1" id="deleteModal-<?php echo e($analyst->company_id); ?>">
                   <div class="modal-dialog" role="document">
                       <div class="modal-content">
                           <div class="modal-header">

                               <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                                   <em class="icon ni ni-cross"></em>
                               </a>
                           </div>
                           <div class="modal-body modal-body-lg text-center">
                            <div class="nk-modal">
                                <em class="nk-modal-icon icon icon-circle icon-circle-xxl ni ni-cross-circle bg-danger"></em>
                                <h4 class="nk-modal-title">You are about to delete <?php echo e($analyst->company->name); ?> ?</h4>
                                <div class="nk-modal-text">
                                    <div class="caption-text">You can't undo this action.</div>

                                </div>
                                <div class="nk-modal-action">


                                    <form method="POST" id="deleteModal1-<?php echo e($analyst->id); ?>"  action="<?php echo e(route('deleteAnalyst', $analyst->company_id)); ?>"><?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-lg btn-mw btn-primary">Delete</button>
                                    </form>
                                </div>

                            </div>
                        </div><!-- .modal-body -->

                       </div>
                   </div>
               </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\laravel_react\nasdnasdep\resources\views/companies/analysts.blade.php ENDPATH**/ ?>